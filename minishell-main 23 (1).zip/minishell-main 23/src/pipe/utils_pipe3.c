/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_pipe3.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <fatmtahmdabrahym@stud    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 09:20:31 by kyung-ki          #+#    #+#             */
/*   Updated: 2025/08/30 02:11:45 by fatmtahmdab      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"

char	**one_commnad(char **args, char **envp, t_node *node)
{
	if (redir_chk(node->ori_args))
		(void)exec_redir(args, envp, node);
	envp = find_command(args, envp, node);
	if (node->redir_flag)
		backup_restor(node);
	return (envp);
}
